local TSM = select(2, ...)

-- The below table is automatically generated based on data from wowuction.com
