-- THIS FILE IS POPULATED BY THE TSM APPLICATION AND SHOULD NOT BE CHANGED OTHERWISE
local TSM = select(2, ...)
TSM.AppData = {groupImports={}, shoppingSearches={}}